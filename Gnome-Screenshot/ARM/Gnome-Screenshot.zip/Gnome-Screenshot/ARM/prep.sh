#!/bin/bash
# (c) J~Net 2024
#
#
# ./prep.sh
#
#
echo "Program Editing Prep!"
echo ""

sudo apt update
sudo apt install -y build-essential git meson ninja-build libglib2.0-dev libgdk-pixbuf2.0-dev libgtk-3-dev

git clone https://gitlab.gnome.org/GNOME/gnome-screenshot.git

cd gnome-screenshot








